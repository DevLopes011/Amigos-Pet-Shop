function Router(event, context, callback) {
    this.path = event.requestContext.http.path
    this.method = event.requestContext.http.method
    this.callback = callback

    this.route = async function (method, path, handler) {
        if (this.method === method && this.path === path) {
            try {
                if (method !== 'GET') {
                    event.body = JSON.parse(event.body)
                }
                await handler(event, context, callback)
            } catch (error) {
                console.log(error)
                this.callback(null, buildResponse(500, "Data Error"))
            }
        }
    }
}

function buildResponse(statusCode, body) {
    return {
        statusCode,
        body: JSON.stringify(body),
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': true,
        },
    }
}

module.exports = { Router, buildResponse }
