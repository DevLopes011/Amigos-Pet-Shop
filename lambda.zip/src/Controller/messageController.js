const { Router } = require('../index');
const { helloHandler, createMessageHandler } = require('./Handler/messageHandler');

exports.handler = async (event, context, callback) => {
    const router = new Router(event, context, callback);

    // Defina a rota GET /hello
    await router.route('GET', '/hello', helloHandler);

    // Defina a rota POST /message para criar uma nova mensagem
    await router.route('POST', '/message', createMessageHandler);
};
